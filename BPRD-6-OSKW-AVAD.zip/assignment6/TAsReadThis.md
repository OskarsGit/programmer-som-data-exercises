for assignment 7.2 and 7.3 we have named the files exercise<exnumber>.c and these can be run through the interactive mode

in CPar.fsy we have changed ll 103, 110 and 17
in CLex.fsl we have changed ll 31
