appart from the files stated that we needed to edit in the assignment we have created the files:
8_1trace.txt, 8_3ex.c, 8_4sym.out, 8_5ex.out, 8_6ex.out, 8_1.txt, 8_3ex.out, 8_5ex.c, 8_6ex.c
