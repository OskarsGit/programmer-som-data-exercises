void main(int n) { 
  switch (n) {
    case 0:
      { print 10; }
    case 1:
      { print 10; }
    case 2:
      { print 20; if (8%4==0) print 21; }
    case 3:
      { print 31; }
    }
}