void main(int m) {
    print ((m == 0) ? (1111) : (3333));
    ((m == 0) ? (print 1111) : (print 3333));
}